#!/bin/bash

# build and run tests
./configure
make all test
